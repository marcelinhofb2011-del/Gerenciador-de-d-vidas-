export enum DebtCategory {
  CREDIT_CARD = "Cartão de Crédito",
  STUDENT_LOAN = "Empréstimo Estudantil",
  MORTGAGE = "Hipoteca",
  CAR_LOAN = "Financiamento de Veículo",
  PERSONAL_LOAN = "Empréstimo Pessoal",
  MEDICAL = "Médica",
  OTHER = "Outro",
}

export interface Payment {
  id: string;
  amount: number;
  date: string;
}

export interface Debt {
  id: string;
  creditor: string;
  category: DebtCategory;
  totalAmount: number;
  remainingAmount: number;
  apr: number;
  minPayment: number;
  dueDate: string; // This is the due date of the *first* installment
  payments: Payment[];
  isNew?: boolean;
  isDeleting?: boolean;
}

export enum PaymentStrategy {
  SNOWBALL = "Bola de Neve da Dívida",
  AVALANCHE = "Avalanche da Dívida",
}

export interface SuggestedStep {
  creditor: string;
  totalAmount: number;
  reason: string;
}

export enum InstallmentStatus {
  PAID = "Paga",
  DUE = "Vencendo",
  OVERDUE = "Atrasada",
  UPCOMING = "Próxima",
}

export interface Installment {
  number: number;
  totalInstallments: number;
  amount: number;
  dueDate: Date;
  status: InstallmentStatus;
}