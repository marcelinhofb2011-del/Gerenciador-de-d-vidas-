import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Debt, Payment, PaymentStrategy, SuggestedStep } from './types';
import { DebtCategory } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import DebtList from './components/DebtList';
import DebtForm from './components/DebtForm';
import StrategyModal from './components/StrategyModal';
import { getPaymentStrategy } from './services/geminiService';
import { PlusIcon, SparklesIcon } from './components/icons';

const App: React.FC = () => {
  const [debts, setDebts] = useState<Debt[]>([
    { id: '1', creditor: 'Banco Principal', category: DebtCategory.CREDIT_CARD, totalAmount: 5000, remainingAmount: 4500, apr: 22.5, minPayment: 150, dueDate: '2024-08-15', payments: [{id: 'p1', amount: 500, date: '2024-07-15'}] },
    { id: '2', creditor: 'Financiadora Auto', category: DebtCategory.CAR_LOAN, totalAmount: 12000, remainingAmount: 12000, apr: 7.2, minPayment: 350, dueDate: '2024-08-01', payments: [] },
    { id: '3', creditor: 'Empréstimos Federais', category: DebtCategory.STUDENT_LOAN, totalAmount: 25000, remainingAmount: 24750, apr: 5.8, minPayment: 250, dueDate: '2024-08-10', payments: [{id: 'p2', amount: 250, date: '2024-07-10'}] },
  ]);
  const [isDebtFormOpen, setIsDebtFormOpen] = useState(false);
  const [isStrategyModalOpen, setIsStrategyModalOpen] = useState(false);
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null);
  
  const [strategy, setStrategy] = useState<PaymentStrategy | null>(null);
  const [suggestedPlan, setSuggestedPlan] = useState<SuggestedStep[]>([]);
  const [isLoadingStrategy, setIsLoadingStrategy] = useState(false);
  const [strategyError, setStrategyError] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const totalDebt = useMemo(() => debts.reduce((sum, debt) => sum + debt.remainingAmount, 0), [debts]);
  const totalMinPayment = useMemo(() => debts.reduce((sum, debt) => sum + debt.minPayment, 0), [debts]);

  const handleAddDebt = () => {
    setEditingDebt(null);
    setIsDebtFormOpen(true);
  };

  const handleEditDebt = (debt: Debt) => {
    setEditingDebt(debt);
    setIsDebtFormOpen(true);
  };

  const handleDeleteDebt = (id: string) => {
    setDebts(prevDebts => 
        prevDebts.map(debt => 
            debt.id === id ? { ...debt, isDeleting: true } : debt
        )
    );

    setTimeout(() => {
        setDebts(prevDebts => prevDebts.filter(debt => debt.id !== id));
    }, 300);
  };

  const handleSaveDebt = (debtData: Omit<Debt, 'id' | 'remainingAmount' | 'payments'> & { id?: string }) => {
    if (editingDebt) {
        setDebts(debts.map(d => {
            if (d.id === editingDebt.id) {
                const paidAmount = d.totalAmount - d.remainingAmount;
                const newRemainingAmount = debtData.totalAmount - paidAmount;
                return { ...d, ...debtData, remainingAmount: newRemainingAmount > 0 ? newRemainingAmount : 0 };
            }
            return d;
        }));
    } else {
        const newDebt: Debt = {
            ...debtData,
            id: new Date().toISOString(),
            remainingAmount: debtData.totalAmount,
            payments: [],
            isNew: true,
        };
        setDebts(prevDebts => [...prevDebts, newDebt]);

        setTimeout(() => {
            setDebts(prevDebts => prevDebts.map(d => 
                d.id === newDebt.id ? { ...d, isNew: false } : d
            ));
        }, 500);
    }
    setIsDebtFormOpen(false);
    setEditingDebt(null);
  };

  const handleAddPayment = (debtId: string, amount: number) => {
    setDebts(debts.map(debt => {
      if (debt.id === debtId) {
        const newPayment: Payment = {
          id: new Date().toISOString(),
          amount,
          date: new Date().toISOString().split('T')[0],
        };
        const newRemainingAmount = debt.remainingAmount - amount;
        return {
          ...debt,
          remainingAmount: newRemainingAmount > 0 ? newRemainingAmount : 0,
          payments: [...debt.payments, newPayment],
        };
      }
      return debt;
    }));
  };

  const handleGetStrategy = useCallback(async (selectedStrategy: PaymentStrategy) => {
    if (!isOnline) {
        setStrategyError("Você precisa estar online para usar esta funcionalidade.");
        return;
    }
    setIsLoadingStrategy(true);
    setStrategyError(null);
    setStrategy(selectedStrategy);
    try {
      if(debts.length === 0){
        throw new Error("Adicione pelo menos uma dívida para obter uma estratégia.");
      }
      const plan = await getPaymentStrategy(debts, selectedStrategy);
      setSuggestedPlan(plan);
    } catch (error) {
      console.error("Error fetching payment strategy:", error);
      setStrategyError(error instanceof Error ? error.message : "Ocorreu um erro desconhecido.");
    } finally {
      setIsLoadingStrategy(false);
    }
  }, [debts, isOnline]);


  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-6 lg:p-8">
        <Dashboard 
          totalDebt={totalDebt}
          debtCount={debts.length}
          totalMinPayment={totalMinPayment}
          debts={debts}
        />
        
        <div className="mt-8">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
            <h2 className="text-2xl font-bold text-slate-700 dark:text-slate-300">Minhas Dívidas</h2>
            <div className="flex gap-2 w-full sm:w-auto">
                <button
                onClick={() => setIsStrategyModalOpen(true)}
                disabled={debts.length === 0 || !isOnline}
                title={!isOnline ? "Funcionalidade indisponível offline" : "Obter Plano de Pagamento"}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 w-full bg-violet-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-violet-700 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-opacity-75 transition disabled:bg-slate-400 disabled:cursor-not-allowed"
                >
                <SparklesIcon className="w-5 h-5" />
                Obter Plano de Pagamento
                </button>
                <button
                onClick={handleAddDebt}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 w-full bg-teal-500 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-opacity-75 transition"
                >
                <PlusIcon className="w-5 h-5" />
                Adicionar Dívida
                </button>
            </div>
          </div>
          <DebtList 
            debts={debts}
            onEdit={handleEditDebt}
            onDelete={handleDeleteDebt}
            onAddPayment={handleAddPayment}
          />
        </div>
      </main>

      {isDebtFormOpen && (
        <DebtForm 
          debt={editingDebt}
          onSave={handleSaveDebt}
          onClose={() => setIsDebtFormOpen(false)}
        />
      )}

      {isStrategyModalOpen && (
        <StrategyModal
            isOpen={isStrategyModalOpen}
            onClose={() => setIsStrategyModalOpen(false)}
            onGetStrategy={handleGetStrategy}
            plan={suggestedPlan}
            strategy={strategy}
            isLoading={isLoadingStrategy}
            error={strategyError}
        />
      )}
    </div>
  );
};

export default App;