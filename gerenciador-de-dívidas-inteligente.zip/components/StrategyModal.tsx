
import React, { useState } from 'react';
import { PaymentStrategy, SuggestedStep } from '../types';
import { CloseIcon, SparklesIcon } from './icons';

interface StrategyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGetStrategy: (strategy: PaymentStrategy) => void;
  plan: SuggestedStep[];
  strategy: PaymentStrategy | null;
  isLoading: boolean;
  error: string | null;
}

const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const StrategyModal: React.FC<StrategyModalProps> = ({ isOpen, onClose, onGetStrategy, plan, strategy, isLoading, error }) => {
  if (!isOpen) return null;

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="text-center p-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-violet-500 mx-auto"></div>
            <p className="mt-4 text-slate-600 dark:text-slate-400">Analisando suas dívidas e criando seu plano personalizado...</p>
        </div>
      );
    }

    if (error) {
        return (
            <div className="text-center p-8 bg-red-50 dark:bg-red-900/20 rounded-lg">
                <h3 className="text-lg font-semibold text-red-700 dark:text-red-400">Oops! Algo deu errado.</h3>
                <p className="mt-2 text-red-600 dark:text-red-300">{error}</p>
                <button 
                  onClick={() => onGetStrategy(strategy!)}
                  className="mt-4 py-2 px-4 bg-red-500 text-white font-semibold rounded-lg shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  Tentar Novamente
                </button>
            </div>
        )
    }

    if (plan.length > 0 && strategy) {
      return (
        <div>
          <h3 className="text-xl font-bold text-violet-600 dark:text-violet-400">{strategy} - Seu Plano de Ação</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 mb-6">
            {strategy === PaymentStrategy.AVALANCHE 
              ? "Concentre-se em pagar as dívidas com os juros mais altos primeiro para economizar mais dinheiro a longo prazo." 
              : "Concentre-se em pagar as menores dívidas primeiro para obter vitórias rápidas e manter a motivação."}
          </p>
          <ul className="space-y-4">
            {plan.map((step, index) => (
              <li key={index} className="p-4 border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                <div className="flex items-start">
                  <div className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-violet-500 text-white font-bold text-sm">
                    {index + 1}
                  </div>
                  <div className="ml-4">
                    <p className="font-semibold text-slate-800 dark:text-slate-200">{step.creditor} ({formatCurrency(step.totalAmount)})</p>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{step.reason}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      );
    }

    return (
      <div>
        <h3 className="text-xl font-bold text-slate-700 dark:text-slate-300 mb-2">Escolha sua estratégia de pagamento</h3>
        <p className="text-slate-500 dark:text-slate-400 mb-6">Selecione um método e nossa IA criará um plano priorizado para você se livrar das dívidas.</p>
        <div className="space-y-4">
          <button 
            onClick={() => onGetStrategy(PaymentStrategy.SNOWBALL)}
            className="w-full text-left p-4 border-2 border-slate-300 dark:border-slate-600 rounded-lg hover:border-teal-500 dark:hover:border-teal-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 transition group"
          >
            <h4 className="font-semibold text-teal-600 dark:text-teal-400">Bola de Neve da Dívida</h4>
            <p className="text-sm text-slate-600 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200">Pague as dívidas menores primeiro. Ótimo para motivação!</p>
          </button>
          <button 
            onClick={() => onGetStrategy(PaymentStrategy.AVALANCHE)}
            className="w-full text-left p-4 border-2 border-slate-300 dark:border-slate-600 rounded-lg hover:border-violet-500 dark:hover:border-violet-400 hover:bg-violet-50 dark:hover:bg-violet-900/20 transition group"
          >
            <h4 className="font-semibold text-violet-600 dark:text-violet-400">Avalanche da Dívida</h4>
            <p className="text-sm text-slate-600 dark:text-slate-400 group-hover:text-slate-800 dark:group-hover:text-slate-200">Pague primeiro as dívidas com juros mais altos. Economize mais dinheiro!</p>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl p-6 w-full max-w-2xl relative transform transition-all animate-fade-in-up">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <SparklesIcon className="w-6 h-6 text-violet-500" />
            Plano de Pagamento Inteligente
          </h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="mt-6 max-h-[60vh] overflow-y-auto pr-2">
            {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default StrategyModal;
