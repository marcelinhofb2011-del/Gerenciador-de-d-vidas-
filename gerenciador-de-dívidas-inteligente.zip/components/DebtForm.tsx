import React, { useState, useEffect } from 'react';
import { Debt, DebtCategory } from '../types';
import { DEBT_CATEGORIES } from '../constants';
import { CloseIcon } from './icons';

interface DebtFormProps {
  debt: Debt | null;
  onSave: (debt: Omit<Debt, 'id' | 'remainingAmount' | 'payments'> & { id?: string }) => void;
  onClose: () => void;
}

const DebtForm: React.FC<DebtFormProps> = ({ debt, onSave, onClose }) => {
  const [formData, setFormData] = useState({
    creditor: '',
    category: DebtCategory.OTHER,
    totalAmount: 0,
    apr: 0,
    minPayment: 0,
    dueDate: '',
  });

  useEffect(() => {
    if (debt) {
      setFormData({
        creditor: debt.creditor,
        category: debt.category,
        totalAmount: debt.totalAmount,
        apr: debt.apr,
        minPayment: debt.minPayment,
        dueDate: debt.dueDate,
      });
    }
  }, [debt]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'category' ? value : (name === 'totalAmount' || name === 'apr' || name === 'minPayment' ? parseFloat(value) || 0 : value) }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, id: debt?.id });
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-2xl p-6 w-full max-w-lg relative animate-fade-in-up">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors">
            <CloseIcon className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold mb-6 text-slate-700 dark:text-slate-300">{debt ? 'Editar Dívida' : 'Adicionar Nova Dívida'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="creditor" className="block text-sm font-medium text-slate-600 dark:text-slate-400">Nome do Credor</label>
            <input type="text" id="creditor" name="creditor" value={formData.creditor} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"/>
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium text-slate-600 dark:text-slate-400">Categoria</label>
            <select id="category" name="category" value={formData.category} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500">
              {DEBT_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="totalAmount" className="block text-sm font-medium text-slate-600 dark:text-slate-400">Valor Total (R$)</label>
              <input type="number" id="totalAmount" name="totalAmount" value={formData.totalAmount} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"/>
            </div>
            <div>
              <label htmlFor="apr" className="block text-sm font-medium text-slate-600 dark:text-slate-400">APR (%)</label>
              <input type="number" id="apr" name="apr" value={formData.apr} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"/>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="minPayment" className="block text-sm font-medium text-slate-600 dark:text-slate-400">Pagamento Mínimo (R$)</label>
              <input type="number" id="minPayment" name="minPayment" value={formData.minPayment} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"/>
            </div>
            <div>
              <label htmlFor="dueDate" className="block text-sm font-medium text-slate-600 dark:text-slate-400">Data de Vencimento</label>
              <input type="date" id="dueDate" name="dueDate" value={formData.dueDate} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"/>
            </div>
          </div>
          
          <div className="flex justify-end gap-4 pt-4">
            <button type="button" onClick={onClose} className="py-2 px-4 bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-200 font-semibold rounded-lg shadow-md hover:bg-slate-300 dark:hover:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-400">
              Cancelar
            </button>
            <button type="submit" className="py-2 px-4 bg-teal-500 text-white font-semibold rounded-lg shadow-md hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-500">
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DebtForm;
