
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white dark:bg-slate-800 shadow-md">
      <div className="container mx-auto px-4 md:px-6 py-4">
        <h1 className="text-3xl font-bold text-teal-600 dark:text-teal-400 tracking-tight">
          Gerenciador de Dívidas Inteligente
        </h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Seu caminho para a liberdade financeira</p>
      </div>
    </header>
  );
};

export default Header;
