import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Debt, DebtCategory } from '../types';
import { CATEGORY_COLORS } from '../constants';

interface DashboardProps {
  totalDebt: number;
  debtCount: number;
  totalMinPayment: number;
  debts: Debt[];
}

const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const Dashboard: React.FC<DashboardProps> = ({ totalDebt, debtCount, totalMinPayment, debts }) => {
  const dataByCategory = debts.reduce((acc, debt) => {
    acc[debt.category] = (acc[debt.category] || 0) + debt.remainingAmount;
    return acc;
  }, {} as { [key in DebtCategory]: number });

  const chartData = Object.entries(dataByCategory).map(([name, value]) => ({
    name: name as DebtCategory,
    value,
  }));
  
  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = <T extends { cx: number; cy: number; midAngle: number; innerRadius: number; outerRadius: number; percent: number; index: number; name: string }>({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }: T) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    if (percent === 0) return null;

    return (
      <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" className="text-xs font-bold">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Summary Cards */}
      <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
          <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Dívida Restante</h3>
          <p className="text-3xl font-bold text-red-500 mt-2">{formatCurrency(totalDebt)}</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
          <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Nº de Dívidas</h3>
          <p className="text-3xl font-bold text-blue-500 mt-2">{debtCount}</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
          <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">Pagamento Mín. Total</h3>
          <p className="text-3xl font-bold text-orange-500 mt-2">{formatCurrency(totalMinPayment)}</p>
        </div>
      </div>

      {/* Chart */}
      <div className="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg min-h-[250px]">
        <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-300 mb-4">Divisão por Categoria</h3>
        {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={renderCustomizedLabel}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                >
                    {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.name]} />
                    ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Legend iconType="circle" />
                </PieChart>
            </ResponsiveContainer>
        ) : (
            <div className="flex items-center justify-center h-full text-slate-500 dark:text-slate-400">
                <p>Adicione dívidas para ver o gráfico.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
