import React from 'react';
import { Debt } from '../types';
import DebtItem from './DebtItem';

interface DebtListProps {
  debts: Debt[];
  onEdit: (debt: Debt) => void;
  onDelete: (id: string) => void;
  onAddPayment: (debtId: string, amount: number) => void;
}

const DebtList: React.FC<DebtListProps> = ({ debts, onEdit, onDelete, onAddPayment }) => {
  if (debts.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md text-center p-10">
        <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-300">Nenhuma dívida encontrada!</h3>
        <p className="text-slate-500 dark:text-slate-400 mt-2">Clique em "Adicionar Dívida" para começar a gerenciar suas finanças.</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
      <div className="hidden md:grid grid-cols-12 gap-4 font-semibold text-xs text-slate-500 dark:text-slate-400 uppercase p-4 border-b border-slate-200 dark:border-slate-700">
        <div className="col-span-3">Credor / Categoria</div>
        <div className="col-span-2 text-right">Valor Restante</div>
        <div className="col-span-2 text-right">APR</div>
        <div className="col-span-2 text-right">Pagamento Mínimo</div>
        <div className="col-span-2 text-right">Vencimento</div>
        <div className="col-span-1 text-right">Ações</div>
      </div>
      <div>
        {debts
          .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
          .map((debt, index) => (
          <DebtItem key={debt.id} debt={debt} onEdit={onEdit} onDelete={onDelete} onAddPayment={onAddPayment} isLast={index === debts.length - 1} />
        ))}
      </div>
    </div>
  );
};

export default DebtList;
