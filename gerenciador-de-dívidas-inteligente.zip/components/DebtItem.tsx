import React, { useState } from 'react';
import { Debt, Installment, InstallmentStatus } from '../types';
import { CATEGORY_COLORS } from '../constants';
import { EditIcon, TrashIcon, ChevronDownIcon } from './icons';

interface DebtItemProps {
  debt: Debt;
  onEdit: (debt: Debt) => void;
  onDelete: (id: string) => void;
  onAddPayment: (debtId: string, amount: number) => void;
  isLast: boolean;
}

const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    date.setUTCDate(date.getUTCDate() + 1);
    return new Intl.DateTimeFormat('pt-BR').format(date);
};

const formatInstallmentDate = (date: Date) => {
    return new Intl.DateTimeFormat('pt-BR', { timeZone: 'UTC' }).format(date);
};

const generateInstallments = (debt: Debt): Installment[] => {
    if (debt.minPayment <= 0 || debt.totalAmount <= 0) return [];

    const totalInstallments = Math.ceil(debt.totalAmount / debt.minPayment);
    const totalPaidAmount = debt.payments.reduce((sum, p) => sum + p.amount, 0);
    const paidInstallmentsCount = Math.floor(totalPaidAmount / debt.minPayment);

    const installments: Installment[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0); 

    const [year, month, day] = debt.dueDate.split('-').map(Number);
    const firstDueDate = new Date(Date.UTC(year, month - 1, day));

    for (let i = 1; i <= totalInstallments; i++) {
        const dueDate = new Date(firstDueDate);
        dueDate.setUTCMonth(dueDate.getUTCMonth() + i - 1);

        let amount = debt.minPayment;
        if (i === totalInstallments) {
            const remaining = debt.totalAmount - (debt.minPayment * (totalInstallments - 1));
            amount = remaining > 0 ? remaining : debt.minPayment;
        }

        let status: InstallmentStatus;
        if (i <= paidInstallmentsCount) {
            status = InstallmentStatus.PAID;
        } else {
            if (dueDate < today) {
                status = InstallmentStatus.OVERDUE;
            } else if (i === paidInstallmentsCount + 1) {
                status = InstallmentStatus.DUE;
            } else {
                status = InstallmentStatus.UPCOMING;
            }
        }
        
        installments.push({
            number: i,
            totalInstallments,
            amount,
            dueDate,
            status,
        });
    }

    return installments;
};

const InstallmentItem: React.FC<{ installment: Installment; onPay: () => void; isNextPayable: boolean }> = ({ installment, onPay, isNextPayable }) => {
    const statusConfig = {
        [InstallmentStatus.PAID]: {
            bgColor: 'bg-green-100 dark:bg-green-900/40',
            textColor: 'text-green-700 dark:text-green-400',
            buttonClasses: 'bg-green-500 text-white',
            buttonText: 'Paga',
        },
        [InstallmentStatus.DUE]: {
            bgColor: 'bg-blue-100 dark:bg-blue-900/40',
            textColor: 'text-blue-700 dark:text-blue-400',
            buttonClasses: 'bg-blue-500 hover:bg-blue-600 text-white',
            buttonText: 'Pagar Agora',
        },
        [InstallmentStatus.OVERDUE]: {
            bgColor: 'bg-red-100 dark:bg-red-900/40',
            textColor: 'text-red-700 dark:text-red-400',
            buttonClasses: 'bg-red-500 hover:bg-red-600 text-white',
            buttonText: 'Pagar Atrasada',
        },
        [InstallmentStatus.UPCOMING]: {
            bgColor: 'bg-slate-100 dark:bg-slate-700/50',
            textColor: 'text-slate-500 dark:text-slate-400',
            buttonClasses: 'bg-slate-300 dark:bg-slate-600 text-slate-500 dark:text-slate-400',
            buttonText: 'Pagar',
        }
    };

    const config = statusConfig[installment.status];
    const isPayable = installment.status === InstallmentStatus.DUE || installment.status === InstallmentStatus.OVERDUE;
    const buttonDisabled = installment.status === InstallmentStatus.PAID || installment.status === InstallmentStatus.UPCOMING || !isNextPayable;

    return (
        <li className={`flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 rounded-md ${config.bgColor}`}>
            <div className="flex items-center">
                <span className={`font-bold text-sm sm:text-base w-14 text-center ${config.textColor}`}>
                    {installment.number}/{installment.totalInstallments}
                </span>
                <div className="ml-4">
                    <p className={`font-semibold ${config.textColor}`}>{formatCurrency(installment.amount)}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Vencimento: {formatInstallmentDate(installment.dueDate)}</p>
                </div>
            </div>
            <div className="w-full sm:w-auto mt-2 sm:mt-0 flex flex-row-reverse sm:flex-col items-center sm:items-end justify-between">
                <span className={`text-xs font-bold uppercase px-2 py-1 rounded-full ${config.textColor}`}>{installment.status}</span>
                <button
                    onClick={onPay}
                    disabled={buttonDisabled}
                    className={`mt-0 sm:mt-2 py-1.5 px-4 text-sm font-semibold rounded-lg shadow-md transition w-auto ${config.buttonClasses} disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-800`}
                >
                    {config.buttonText}
                </button>
            </div>
        </li>
    );
};


const DebtItem: React.FC<DebtItemProps> = ({ debt, onEdit, onDelete, onAddPayment, isLast }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const categoryColor = CATEGORY_COLORS[debt.category];
  const percentagePaid = debt.totalAmount > 0 ? ((debt.totalAmount - debt.remainingAmount) / debt.totalAmount) * 100 : 0;
  
  const installments = isExpanded ? generateInstallments(debt) : [];
  const nextPayableInstallmentIndex = installments.findIndex(inst => inst.status === InstallmentStatus.DUE || inst.status === InstallmentStatus.OVERDUE);
  
  const animationClasses = debt.isNew ? 'animate-item-enter' : debt.isDeleting ? 'animate-item-exit' : '';

  return (
    <div className={`transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/50 ${!isLast ? 'border-b border-slate-200 dark:border-slate-700' : ''} ${animationClasses}`}>
        <div className="grid grid-cols-12 gap-4 items-center p-4">
            <div className="col-span-12 md:col-span-3 flex flex-col justify-center">
                <div className="flex items-center">
                    <span className="w-2 h-8 rounded-full mr-3 flex-shrink-0" style={{ backgroundColor: categoryColor }}></span>
                    <div>
                        <p className="font-semibold text-slate-800 dark:text-slate-200">{debt.creditor}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{debt.category}</p>
                    </div>
                </div>
                <div className="mt-2 pl-5">
                    <div className="w-full bg-slate-200 rounded-full h-1.5 dark:bg-slate-600">
                        <div className="bg-teal-500 h-1.5 rounded-full" style={{ width: `${percentagePaid}%` }} title={`${percentagePaid.toFixed(1)}% pago`}></div>
                    </div>
                </div>
            </div>

            <div className="col-span-6 md:col-span-2 text-right">
                <span className="md:hidden text-xs font-bold text-slate-500 dark:text-slate-400">RESTANTE: </span>
                <span className="font-medium">{formatCurrency(debt.remainingAmount)}</span>
                <p className="text-xs text-slate-400">de {formatCurrency(debt.totalAmount)}</p>
            </div>
            <div className="col-span-6 md:col-span-2 text-right">
                <span className="md:hidden text-xs font-bold text-slate-500 dark:text-slate-400">APR: </span>
                <span className="font-medium">{debt.apr.toFixed(2)}%</span>
            </div>
            <div className="col-span-6 md:col-span-2 text-right">
                <span className="md:hidden text-xs font-bold text-slate-500 dark:text-slate-400">PAG. MÍN.: </span>
                <span className="font-medium text-orange-500">{formatCurrency(debt.minPayment)}</span>
            </div>
            <div className="col-span-6 md:col-span-2 text-right">
                <span className="md:hidden text-xs font-bold text-slate-500 dark:text-slate-400">VENC.: </span>
                <span className="font-medium">{formatDate(debt.dueDate)}</span>
            </div>

            <div className="col-span-12 md:col-span-1 flex justify-end items-center gap-1 mt-2 md:mt-0">
                <button onClick={() => onEdit(debt)} className="p-2 text-slate-500 hover:text-blue-500 transition-colors rounded-full hover:bg-slate-200 dark:hover:bg-slate-600" aria-label="Editar">
                    <EditIcon className="w-5 h-5" />
                </button>
                <button onClick={() => onDelete(debt.id)} className="p-2 text-slate-500 hover:text-red-500 transition-colors rounded-full hover:bg-slate-200 dark:hover:bg-slate-600" aria-label="Excluir">
                    <TrashIcon className="w-5 h-5" />
                </button>
                <button onClick={() => setIsExpanded(!isExpanded)} className="p-2 text-slate-500 hover:text-teal-500 transition-colors rounded-full hover:bg-slate-200 dark:hover:bg-slate-600" aria-label="Ver parcelas">
                    <ChevronDownIcon className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                </button>
            </div>
        </div>
        {isExpanded && (
            <div className="p-4 md:px-8 lg:px-12 bg-slate-100 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 animate-fade-in-down">
                <h4 className="font-semibold text-slate-700 dark:text-slate-300 mb-3">Plano de Parcelamento</h4>
                {installments.length > 0 ? (
                    <ul className="space-y-2 max-h-60 overflow-y-auto pr-2">
                       {installments.map((inst, index) => (
                           <InstallmentItem 
                                key={inst.number}
                                installment={inst}
                                onPay={() => onAddPayment(debt.id, inst.amount)}
                                isNextPayable={index === nextPayableInstallmentIndex}
                           />
                       ))}
                    </ul>
                ) : (
                    <p className="text-sm text-slate-500 dark:text-slate-400">O valor total ou o pagamento mínimo não foi definido. Não é possível gerar parcelas.</p>
                )}
            </div>
        )}
    </div>
  );
};

export default DebtItem;