/// <reference lib="webworker" />

const CACHE_NAME = 'debt-manager-v1';
const STATIC_ASSETS_TO_PRECACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
];

// On install, precache the app shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Precaching static assets');
      return cache.addAll(STATIC_ASSETS_TO_PRECACHE);
    })
  );
  self.skipWaiting();
});

// On activate, clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// On fetch, use stale-while-revalidate strategy for all requests
self.addEventListener('fetch', (event) => {
  // Don't cache calls to the Gemini API
  if (event.request.url.includes('generativelanguage')) {
    // Respond with a fetch request
    return event.respondWith(fetch(event.request));
  }

  event.respondWith(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.match(event.request).then((cachedResponse) => {
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          // If the request is successful, update the cache
          // Only cache GET requests
          if (networkResponse.ok && event.request.method === 'GET') {
             cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        }).catch(err => {
            console.error('Fetch failed; returning offline page instead.', err);
            // If the request fails (e.g., offline) and we have a cached response,
            // we've already returned it. If not, this catch is for logging.
            // The `cachedResponse || fetchPromise` handles returning the cache if fetch fails.
            throw err;
        });

        // Return the cached response immediately, and update the cache in the background.
        return cachedResponse || fetchPromise;
      });
    })
  );
});
