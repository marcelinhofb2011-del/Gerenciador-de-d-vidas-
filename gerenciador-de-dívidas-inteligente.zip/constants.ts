
import { DebtCategory } from './types';

export const DEBT_CATEGORIES: DebtCategory[] = [
  DebtCategory.CREDIT_CARD,
  DebtCategory.STUDENT_LOAN,
  DebtCategory.MORTGAGE,
  DebtCategory.CAR_LOAN,
  DebtCategory.PERSONAL_LOAN,
  DebtCategory.MEDICAL,
  DebtCategory.OTHER,
];

export const CATEGORY_COLORS: { [key in DebtCategory]: string } = {
  [DebtCategory.CREDIT_CARD]: '#ef4444', // red-500
  [DebtCategory.STUDENT_LOAN]: '#3b82f6', // blue-500
  [DebtCategory.MORTGAGE]: '#22c55e', // green-500
  [DebtCategory.CAR_LOAN]: '#f97316', // orange-500
  [DebtCategory.PERSONAL_LOAN]: '#a855f7', // purple-500
  [DebtCategory.MEDICAL]: '#ec4899', // pink-500
  [DebtCategory.OTHER]: '#71717a', // zinc-500
};
