
import { GoogleGenAI, Type } from "@google/genai";
import { Debt, PaymentStrategy, SuggestedStep } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getPaymentStrategy = async (debts: Debt[], strategy: PaymentStrategy): Promise<SuggestedStep[]> => {
  const model = "gemini-2.5-flash";

  const debtList = debts.map(d => ({
    creditor: d.creditor,
    totalAmount: d.totalAmount,
    apr: d.apr,
    minPayment: d.minPayment,
  }));

  const strategyDescription = strategy === PaymentStrategy.AVALANCHE
    ? "Avalanche da Dívida (priorizar a maior APR)"
    : "Bola de Neve da Dívida (priorizar o menor saldo)";

  const prompt = `
    Você é um consultor financeiro especialista em gestão de dívidas.
    Com base na lista de dívidas a seguir e na estratégia de pagamento escolhida, forneça um plano de pagamento passo a passo.
    Liste as dívidas em ordem de prioridade de pagamento. Para cada dívida, forneça uma breve razão para sua posição na lista, com base na estratégia.

    Estratégia Escolhida: ${strategyDescription}

    Lista de Dívidas:
    ${JSON.stringify(debtList, null, 2)}

    Sua resposta deve ser apenas o JSON, seguindo estritamente o esquema fornecido.
  `;
  
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              creditor: {
                type: Type.STRING,
                description: 'O nome do credor.',
              },
              totalAmount: {
                type: Type.NUMBER,
                description: 'O valor total devido a este credor.',
              },
              reason: {
                type: Type.STRING,
                description: 'A razão pela qual esta dívida é priorizada, com base na estratégia.',
              },
            },
            required: ['creditor', 'totalAmount', 'reason'],
          },
        },
      },
    });

    const jsonText = response.text;
    if (!jsonText) {
      throw new Error("A API retornou uma resposta vazia.");
    }

    // A resposta já é um objeto JSON se o schema for usado corretamente.
    const parsedPlan = JSON.parse(jsonText);
    return parsedPlan as SuggestedStep[];

  } catch (error) {
    console.error("Erro detalhado da API Gemini:", error);
    throw new Error("Não foi possível gerar a estratégia de pagamento. Por favor, tente novamente.");
  }
};
